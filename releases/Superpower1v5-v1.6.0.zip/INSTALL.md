# Superpower 1v5 v1.6.0

Requires CS2 dedicated server, Metamod:Source, CounterStrikeSharp API 1.0.380.0 and its .NET 10 runtime. Tested on Windows; Linux has not been verified.

## Install

1. Stop the destination server or unload the previous plugin.
2. Back up any existing Superpower1v5 plugin/config.
3. Extract this ZIP into game/csgo/ and merge addons/. If your host opens directly in csgo/, extract there.
4. Confirm addons/counterstrikesharp/plugins/Superpower1v5/Superpower1v5.dll exists. Keep its .deps.json and .pdb alongside it.
5. The included config goes at addons/counterstrikesharp/configs/plugins/Superpower1v5/Superpower1v5.json.
6. Restart the server and run css_plugins list and css_sp_debug in the server console.

This archive contains only the plugin, configuration and instructions. It does not include server binaries, framework/API binaries, credentials, logs or test servers.

## Play

Choose T to become the boss. You stay T and keep that role until you leave or switch teams. The T slot is limited to one boss; other players join CT. Nobody is randomly promoted from CT. A human choosing T can replace a bot boss.

The boss receives two equally likely powers from an 18-power pool. Only the boss receives the loadout names, descriptions, HUD and ability notices. Normal health is 100; Juggernaut gives the boss 500 HP.

Wall Vision, Invisibility and Juggernaut work automatically. Invisibility filters the boss's body and attached equipment out of other clients' transmissions. Cluster Grenade turns every standard thrown utility into four projectiles of that type, without recursive splitting.

Second Chance prevents one lethal damage hit and rewinds position, facing, velocity, health and armor about three seconds. It validates the landing, provides a brief recovery window and reapplies teleport after the damage flow. Forced deaths such as Random Kill bypass it.

Random Kill retains ID random_explosion: instantly kill one random living player, including the boss, without an explosion. Cooldown: 20 seconds.

## Commands

Chat: !power, !powers, !cooldowns, !ability1, !ability2, !help.
Client binds: bind v css_ability1 and bind b css_ability2.

Server console testing:

```text
bot_quota_mode normal
bot_quota 5
mp_warmup_end
mp_restartgame 1
css_sp_debug
css_sp_give "YourPlayerName" juggernaut 1
css_sp_give "YourPlayerName" cluster_grenade 2
```

Assigning powers requires the current boss. css_sp_setboss <player> is an admin override that moves the selected player to T. In-game admin commands require @css/generic in the destination server's CounterStrikeSharp admin settings.

Native grenade factories and secondary damage bindings require revalidation after game/framework updates. Human rendering of invisibility and wall outlines still needs playtesting. Some isolated Windows test runs report a known shutdown access violation after successful unload; completed gameplay checks passed.