# Superpower1v5 v1.9.0

Requires a CS2 dedicated server with Metamod:Source, CounterStrikeSharp API 1.0.380.0, and its .NET 10 runtime. The package was tested on Windows.

1. Back up your existing plugin and config, then stop the server.
2. Extract this archive into the server's `game/csgo/` directory and merge the `addons/` folders.
3. The included default configuration uses version 11. To migrate a customized config, build from the v1.9.0 source checkout and run `tools/Deploy.ps1 -MigrateConfig`.
4. Restart the server and run `css_plugins list` and `css_sp_debug` in the server console.

Use `!ability1` and `!ability2` to activate powers. Native deathmatch can be started with `+game_alias deathmatch`.

Decoy Clone's walking animations use AnimGraph2 on Windows CS2 build 26879581. Other builds use the standard moving prop.

[Release and downloads](https://github.com/Ha1wen/Superpower1v5/releases/tag/v1.9.0)  
[Verification](https://github.com/Ha1wen/Superpower1v5/blob/v1.9.0/docs/VERIFICATION.md)
