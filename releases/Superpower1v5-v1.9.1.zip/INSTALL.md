# Superpower1v5 v1.9.1

Requires a CS2 dedicated server with Metamod:Source, CounterStrikeSharp API 1.0.380.0 or newer, and its .NET 10 runtime.

1. Back up the plugin and config, then stop the server.
2. Extract the archive into the server's game/csgo directory and merge the addons folders. The archive contains the default plugin configuration. Restore your existing configuration if you want to keep your settings.
3. Restart the server and run css_plugins list and css_sp_debug in the server console.

This update suppresses custom gloves, weapon nameplates, and StatTrak displays during Invisibility. It uses the server's existing CounterStrikeSharp settings.

[Source and documentation](https://github.com/Ha1wen/Superpower1v5)
