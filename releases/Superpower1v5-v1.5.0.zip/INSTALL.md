# Superpower 1v5 v1.5.0

Upload package containing the production plugin and the current 16-power configuration.

## Requirements

- CS2 dedicated server with Metamod:Source and CounterStrikeSharp installed.
- CounterStrikeSharp API 1.0.380.0 and its .NET 10 runtime. This DLL targets net10.0.
- This release was tested on Windows. Other operating systems have not been verified.
- Framework/API DLLs and game binaries are supplied by your server, not this package.

## Install

1. Stop the destination server, or unload any existing Superpower 1v5 instance.
2. Extract this ZIP into the destination server's `game/csgo/` directory. For hosting panels that open directly in `csgo/`, extract there. Merge the included `addons/` folder.
3. Confirm the plugin DLL is at `addons/counterstrikesharp/plugins/Superpower1v5/Superpower1v5.dll`.
4. The included configuration goes at `addons/counterstrikesharp/configs/plugins/Superpower1v5/Superpower1v5.json`. Back up an existing config before replacing it. This package includes the current server settings.
5. Start/restart the server. Run `css_plugins list`, then `css_sp_debug` in the server console to verify loading.

Keep the .deps.json and .pdb beside the DLL. No compilation is required on the destination server. The archive contains no other plugins, credentials, server.cfg, game assets, or diagnostic test server.

## Play and test

One rotating boss receives two different powers against up to five normal players. Everyone starts at 100 HP. All 16 powers have equal selection chances. Bots are enabled in this configuration.

Run in the dedicated server console:

```text
bot_quota_mode normal
bot_quota 5
bot_stop 0
mp_warmup_end
mp_restartgame 1
css_sp_debug
```

With one human and five bots, the human has boss priority. To assign a test pair to the current boss:

```text
css_sp_give "YourPlayerName" wall_vision 1
css_sp_give "YourPlayerName" invisibility 2
```

Wall Vision and Invisibility work automatically while assigned. They do not require activation. For activated powers, use `!ability1` or `!ability2` in chat, or bind `v` to `css_ability1` and `b` to `css_ability2`. Use `!powers` to list all IDs and `!cooldowns` to check status. Server console admin commands need no player permission; in-game admin commands require `@css/generic` in your destination server's CounterStrikeSharp admin settings.

`random_explosion` now displays as Random Kill: immediately kill one random living player, including the boss, without an explosion. Cooldown: 20 seconds. Yoru Flash and rarity tiers have been removed.

Power IDs: super_speed, vampirism, invisibility, teleport, explosive_bullets, infinite_ammo, rapid_fire, low_gravity, wall_vision, knockback, second_chance, bhop, sandevistan, pyromaniac, random_explosion, tiny.

## Compatibility notes

Native secondary damage was verified against the API 380 engine binding. Revalidate after changing game/framework versions. Human rendering of translucent models and wall outlines still needs client playtesting. The isolated Windows test host reports an existing access violation on quit after successful plugin unload; gameplay checks passed.