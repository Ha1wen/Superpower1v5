# Superpower1v5 v1.8.0

Requires Windows CS2, Metamod:Source, CounterStrikeSharp API 1.0.380.0 and its .NET 10 runtime.

1. Back up your existing Superpower1v5 plugin and configuration.
2. Stop the server, then extract this ZIP into game/csgo/, merging addons/.
3. This archive includes default configuration (ConfigVersion 8). If upgrading a tuned configuration, retain it and add the new power settings, or use tools/Deploy.ps1 -MigrateConfig from the source checkout to migrate it automatically.
4. Restart the server. Run css_plugins list and css_sp_debug in the dedicated server console.

In 1v5, join T for two private powers against up to five CT players. Native deathmatch (+game_alias deathmatch, game_type 1/game_mode 2) gives everyone a different pair on each respawn with fresh cooldowns and one-use state.

Players: !power, !powers, !ability1, !ability2, !cooldowns and !help.
Client binds: bind v css_ability1; bind b css_ability2.
Administrator commands require @css/generic; server console commands work directly.

New powers: infinite_jump (press jump again in midair), random_teleport (20-second cooldown), forcefield (10 seconds of invincibility, 35-second cooldown).

This version adjusts Tiny aim alignment, removes Rapid Fire recoil, hardens Second Chance after Teleport, makes Invisibility exclude planted bombs and suppress radar spotting, and replaces Pyromaniac's custom pools with real spreading Molotov fire.

Validation: 35 automated checks and 24 native gameplay checks passed. Tiny crosshair alignment and Invisibility's client rendering/crash regression still need human playtesting. A previously documented Windows access violation can occur during server shutdown after successful plugin unload; it remains unresolved.

Source and detailed verification:
https://github.com/Ha1wen/Superpower1v5
https://github.com/Ha1wen/Superpower1v5/blob/main/docs/VERIFICATION.md
