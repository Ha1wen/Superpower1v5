# Superpower1v5 v1.7.0

Requires a CS2 dedicated server, Metamod:Source, CounterStrikeSharp API 380 or newer and its .NET 10 runtime. This ZIP contains the plugin alone. Windows is verified; Linux has not been tested.

1. Back up any existing plugin and configuration. Stop the destination server while installing.
2. Extract into the destination server's game/csgo/ directory, merging addons/. A hosting panel may already open in csgo/.
3. Start the server. Run css_plugins list and css_sp_debug in its console.

The DLL must be at addons/counterstrikesharp/plugins/Superpower1v5/Superpower1v5.dll.
Configuration: addons/counterstrikesharp/configs/plugins/Superpower1v5/Superpower1v5.json.
Existing configuration is supported and validated as ConfigVersion 7. Preserve your customized JSON when upgrading; the included example shows the new settings.

Server commands:
- css_sp_random_boss 1: randomly promote a boss next round. Use 0 to keep the person who chose T.
- css_sp_showpowers 1: publicly announce assigned powers during rounds. Use 0 for private assignments.
- css_sp_everyone 1: give every active T/CT player two powers. Use 0 for boss-only powers.
All three also accept toggle; without an argument they show status. Changes persist to configuration. Defaults are all 0. Team limits remain one T versus up to five CT players.

Powers are always revealed publicly at round end, including dead players' powers. !power, !cooldowns, !ability1 and !ability2 work for each powered player. Bind examples: bind v css_ability1; bind b css_ability2.

Invisibility automatically reveals on sound. After 0.5 seconds of silence, fade out over 1 second. Shift/crouch walking is quiet; running, shooting and reloading reveal you. Configure InvisibilityQuietDelay and InvisibilityFadeDuration in the JSON.

31 automated checks and 50 isolated bot gameplay checks pass. A lethal AK headshot/rewind was verified. Human rendering still needs client playtesting. Some private Windows tests encounter an existing engine shutdown access violation after successful unload; gameplay results are separate from shutdown. Native grenade/damage bindings require revalidation after engine/framework updates.

Repository and verification: https://github.com/Ha1wen/Superpower1v5 (private).